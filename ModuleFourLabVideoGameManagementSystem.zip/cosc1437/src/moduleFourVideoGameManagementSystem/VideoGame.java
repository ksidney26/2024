//Name: Karl Sidney 
//Last Modified: 3/9/24
//This Java class is used to hold information about video games for the "Video Game Management System" Lab.

package moduleFourVideoGameManagementSystem;

import java.text.NumberFormat;
import java.util.ArrayList;

public class VideoGame {

	//Variables

	private ArrayList<VideoGame> Games;
	private String title;
	private String genre;
	private String platform;
	private double price;
	NumberFormat formatter = NumberFormat.getCurrencyInstance();

	// Parameterized Constructor

	public VideoGame(String title, String genre, String platform, double price) {
		this.title = title;
		this.genre = genre;
		this.platform = platform;
		this.price = price;
	}

	//Default Constructor

	public VideoGame () {
		this.title = "Title not found";
		this.genre = "Genre not found";
		this.platform = "Platform not found";
		this.price = 0.00;
	}

	//Copy Constructor

	public VideoGame(VideoGame pVideoGame) { 
		this.title = pVideoGame.title;
		this.genre = pVideoGame.genre;
		this.platform = pVideoGame.platform;
		this.price = pVideoGame.price;
	}

	// Getters

	public String getTitle() {
		return title;
	}

	public String getGenre() {
		return genre;
	}

	public String getPlatform() {
		return platform;
	}

	public double getPrice() {
		return price;
	}

	public ArrayList<VideoGame> getGames() {
		return Games;
	}

	// Setters

	public void setTitle(String title) {
		this.title = title;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public void setGames(ArrayList<VideoGame> games) {
		Games = games;
	}

	// ToString for displaying VideoGame info

	public String toString() {
		String description;
		description =  "╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════"+"\n";
		description += "║"+"Title: " + title + "\n";
		description += "║"+"Genre: " + genre + "\n";
		description += "║"+"Platform: " + platform + "\n";
		description += "║"+"Price: " +formatter.format(this.getPrice()) + "\n";
		description += "╚══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════";
		return description;
	}
}
