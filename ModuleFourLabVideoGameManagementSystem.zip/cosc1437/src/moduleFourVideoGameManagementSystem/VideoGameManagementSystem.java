//Name: Karl Sidney 
//Last Modified: 3/9/24
//This Java class is used to hold information about video games for the "Video Game Management System" Lab.

package moduleFourVideoGameManagementSystem;

import java.util.ArrayList;
import java.util.Scanner;

public class VideoGameManagementSystem {

	public static void main(String[] args) {

	// Initiate scanner and other variables

	Scanner keyboard = new Scanner(System.in);
	int answer;
	
	// Create ArrayList to hold game collection

	ArrayList<VideoGame> Games = new ArrayList<>();

	// List of games

	Games.add(new VideoGame("Halo 3", "First Person Shooter","Xbox", 59.99));
	Games.add(new VideoGame("Helldivers 2", "Arcade Shooter", "PC", 39.99));
	Games.add(new VideoGame("Hunt Showdown", "Extraction Shooter", "PC", 39.99));
	Games.add(new VideoGame("For Honor", "Arcade Fighting","Cross Platform", 19.99));
	Games.add(new VideoGame("Super Mario", "Side Platformer","Nintendo", 29.99));

	// Main menu prompts

	do {
	System.out.println("╔══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════");
	System.out.println("║"+"Main Menu");
	System.out.println("║"+"Add Game              Press 1");
	System.out.println("║"+"Search for Game       Press 2");
	System.out.println("║"+"Display Collection    Press 3");
	System.out.println("║"+"Close Program         Press 4");
	System.out.println("╚══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════");
	answer = keyboard.nextInt();
	keyboard.nextLine();
		if (answer == 1) {
			addGame(Games);
		}else if (answer == 2) {
			searchGames(Games);
		}else if (answer == 3) {
			displayInventory(Games);
		}else if (answer == 4) {
			closeProgram();
		}
		} while (answer != 4);
	}

	// Method for adding games

	public static void addGame(ArrayList<VideoGame> Games) {
		// Variables
		Scanner keyboard = new Scanner(System.in);
		String gameTitle;
		String gameGenre;
		String gamePlatform;
		double gamePrice;
		
		// User prompts
		System.out.println("\n" + "What is the title of this game?");
		gameTitle = keyboard.nextLine();

		System.out.println("\n" + "What is the genre?" + "\n");
		gameGenre = keyboard.nextLine();

		System.out.println("\n" + "Which platform supports it?" + "\n");
		gamePlatform = keyboard.nextLine();

		System.out.println("\n" + "How much did it cost?" + "\n");
		gamePrice = keyboard.nextDouble();
		keyboard.nextLine();
		Games.add(new VideoGame(gameTitle, gameGenre, gamePlatform, gamePrice));
		System.out.println(gameTitle + " added." + "\n");
	}

	// Method for searching games

	public static void searchGames(ArrayList<VideoGame> Games) {
		Scanner keyboard = new Scanner(System.in);
		String search;
		System.out.println("Search: ");
		System.out.print("Enter the title of the game you are looking for.");
		search = keyboard.nextLine();
		boolean found = false;
		for(VideoGame games : Games) {
			if (games.getTitle().equalsIgnoreCase(search)) {
			System.out.println("Game Found: ");
			System.out.println(games.toString());
			found = true;
			break;
			}
		}
		if(!found) {
			System.out.println("Game not found.");
		}
	}

	// Method for displaying inventory using BubbleSort algorithm to sort alphabetically by title

	public static void displayInventory(ArrayList<VideoGame> games) {
	for (int i = 0; i < games.size() - 1; i++) {
	for (int j = 0; j < games.size() - i - 1; j++) {

	// Compare titles and swap if necessary

	if (games.get(j).getTitle().compareToIgnoreCase(games.get(j + 1).getTitle()) > 0) {
		VideoGame temp = games.get(j);
		games.set(j, games.get(j + 1));
		games.set(j + 1, temp);
				}
			}
		}

	// Display sorted inventory

		System.out.println("Inventory (Sorted Alphabetically by Title):");
		for (VideoGame game : games) {
		System.out.println(game);
		}
	}

	// Method to end the program

	public static void closeProgram() {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Program Terminated.");
		keyboard.close();
		System.exit(0);
	}
}
