//Name: Karl Sidney 
//Last Modified: 2/23/24
//This Java class is used to hold information for the static header class.

package moduleThreeLabUniversity;

public class Header {
	private static int numberTimesUsed = 0;

	// Header

	public static String PrintHeader(String pText) {
		String myReturn = "";
		myReturn += Spacer();
		myReturn += pText + "\n";
		myReturn += Spacer();
		numberTimesUsed++;
		return myReturn;
	}

	// Header with no argument

	public static String PrintHeader() {
		String myReturn = "";
		myReturn += Spacer();
		myReturn += "*****University Module Demonstration*****\n";
		myReturn += Spacer();
		numberTimesUsed++;
		return myReturn;
		}

	// Footer

	public static String PrintFooter() {
		String myReturn = "";
		myReturn += Spacer('_');
		myReturn += "End of Program\n";
		myReturn += Spacer('_');
		numberTimesUsed++;
		return myReturn;
	}

	// Method for spacer

	private static String Spacer() {
	return"_________________________________________________\n";
	}

	// Method for overloaded spacer

	private static String Spacer(char myChar) {
	String myReturn = "";
	for(int i = 0; i < 25; i++) {
	myReturn += myChar;
	}
	return myReturn + "\n";
	}

	// Get number of time used

	public static int getTimesUsed() {
		return numberTimesUsed;
	}
}