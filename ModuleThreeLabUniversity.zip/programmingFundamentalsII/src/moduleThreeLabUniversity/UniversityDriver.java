//Name: Karl Sidney 
//Last Modified: 2/2/24
//This Java class is used as the driver for the "University" lab in the module three lab.

package moduleThreeLabUniversity;

import java.util.Scanner;

public class UniversityDriver {

	public static void main(String[] args) {

	// Variables

	String myCourseName;
	String myCourseCode;
	String myProfessorName;
	String myDepartment;
	String myUniversityName;
	String myLocation;

	// Initiate scanner

	Scanner keyboard = new Scanner(System.in);

	// Create header

	System.out.println(Header.PrintHeader());

	// Start user prompts

	System.out.println("\n" + "So, what university are you going to again?" + "\n");
	myUniversityName = keyboard.nextLine();

	System.out.println("\n" + "Cool! Where is that again?" + "\n");
	myLocation = keyboard.nextLine();
 
	System.out.println("\n" + "Who's your professor?" + "\n");
	myProfessorName = keyboard.nextLine();

	System.out.println("\n" + "What course do they teach?" + "\n");
	myCourseName = keyboard.nextLine();

	System.out.println("\n" + "That sounds pretty interesting. What department is their office in?"+ "\n");
	myDepartment = keyboard.nextLine();

	System.out.println("\n" + "Great, I might take that course next year. Do you happen to know the Course Code?" + "\n");
	myCourseCode = keyboard.nextLine();

	System.out.println("\n" + "Thanks, I appreciate all the help." + "\n");
	System.out.println("Here's what I wrote down. Does this look right to you?");

	// Initiate "Course" object with the provided info

	Course myCourse = new Course(myCourseName, myCourseCode);

	// Initiate "Professor" object with the provided info

	Professor myProfessor = new Professor(myProfessorName, myDepartment, myCourse);

	// Initiate "University" object with the provided info

	University myUniversity = new University(myUniversityName, myLocation, myProfessor);

	// Display information to verify.

	System.out.print(myUniversity.universityInfo());
	System.out.print(myProfessor.professorInfo());

	//  Close keyboard and close program

	keyboard.close();
	System.out.println("\n" + Header.PrintFooter());
	}
}