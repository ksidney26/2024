//Name: Karl Sidney 
//Last Modified: 2/24/24
//This Java class is used as a University in the module three lab.

package moduleThreeLabUniversity;

public class University {

	private String universityName;
	private String location;
	public Professor professor;

	// Primary constructor

	public University(String universityName, String location, Professor professor) {
		super();
		this.universityName = universityName;
		this.location = location;
		this.professor = new Professor(professor);
	}

	// Default constructor

	public University() {
		this.universityName = "Unknown name";
		this.location = "Unknown location";
		this.professor = new Professor();
	}

	// Copy constructor

	public University(University pUniversity) {
		this.universityName = pUniversity.universityName;
		this.location = pUniversity.location;
		this.professor = new Professor(pUniversity.professor);
	}

	// Get university name

	public String getUniversityName() {	
		return universityName;
	}

	// Get university's location

	public String getLocation() {
		return location;
	}

	// Get professor

	public Professor getProfessor() {
		return professor;
	}

	// Set university's name

	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}

	// Set university's location

	public void setLocation(String location) {
		this.location = location;
	}

	// Set professor

	public void setProfessor(Professor professor) {
		this.professor = professor;
	}

	// Display the unversity's info

	public String universityInfo() {
		String myReturn = "";
		myReturn += this.getUniversityName() + " " + this.getLocation() + "\n";
		myReturn += this.getProfessor() + "\n";
		return myReturn;
	}

	@Override
	public String toString() {
		return universityName + "\n"
		+ location + "\n" + professor;
	}
}
