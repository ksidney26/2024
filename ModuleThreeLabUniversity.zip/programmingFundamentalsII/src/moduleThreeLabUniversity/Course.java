//Name: Karl Sidney 
//Last Modified: 2/24/24
//This Java class is used for courses in the module three lab.

package moduleThreeLabUniversity;

public class Course {

	private String courseName;
	private String courseCode;

	// Primary constructor

	public Course(String courseName, String courseCode) {
		super();
		this.courseName = courseName;
		this.courseCode = courseCode;
	}

	// Default constructor

	public Course() {
		this.courseName = "Unknown name";
		this.courseCode = "Unknown code";
	}

	// Copy constructor

	public Course(Course pCourse){
		this.courseName = pCourse.courseName;
		this.courseCode = pCourse.courseCode;
		}

	// Get course name

	public String getCourseName() {
		return courseName;
	}

	// Get course code

	public String getCourseCode() {
		return courseCode;
	}

	// Set course name

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	// Set course code

	public void setCourseCode(String courseCode) {
		this.courseCode = courseCode;
	}

	// Display course info

	public String courseInfo() {
		String myReturn = "";
		myReturn += this.getCourseName() + "\n";
		myReturn += this.getCourseCode() + "\n";
		return myReturn;
	}

	@Override
	public String toString() {
		return courseName + "\n" + courseCode;
	}
}
