//Name: Karl Sidney 
//Last Modified: 2/24/24
//This Java class is used as a professor in the module three lab.

package moduleThreeLabUniversity;

public class Professor {

	private String professorName;
	private String department;
	public Course course;
	
	// Primary constructor

	public Professor(String professorName, String department, Course course) {
		super();
		this.professorName = professorName;
		this.department = department;
		this.course = new Course(course);
	}

	// Default constructor

	public Professor() {
		this.professorName = "Unknown name";
		this.department = "Unknown department";
		this.course = new Course();
	}

	// Copy constructor

	public Professor(Professor pProfessor){
		this.professorName = pProfessor.professorName;
		this.department = pProfessor.department;
		this.course = new Course(pProfessor.course);
	}

	// Get professor's name

	public String getProfessorName() {
		return professorName;
	}

	// Get professor's department

	public String getDepartment() {
		return department;
	}

	// Get professor's course

	public Course getCourse() {
		return course;
	}

	// Set professor's name

	public void setProfessorName(String professorName) {
		this.professorName = professorName;
	}

	// Set professor's department

	public void setDepartment(String department) {
		this.department = department;
	}

	// Set professor's course

	public void setCourse(Course course) {
		this.course = course;
	}

	// Display professor info

	public String professorInfo() {
		String myReturn = "";
		myReturn += this.getProfessorName() + " You can find their office in the "+ "\n";
		myReturn += this.getDepartment() + " building. "+"\n";
		myReturn +="Course Code: " + this.getCourse() + "\n";
		return myReturn;
	}

	@Override
	public String toString() {
		return professorName + "\n"
		+ department + "\n" + course;
	}
}
