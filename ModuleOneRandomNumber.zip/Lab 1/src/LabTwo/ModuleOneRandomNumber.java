// Name: Karl Sidney 
// Last Modified: 1/27/24
// This program is for Module One and will simulate a random number based on an upper and lower bound provided by the user.

package LabTwo;
import java.util.Scanner;
import java.util.Random;

public class ModuleOneRandomNumber {

	public static void main(String[] args) {
		
		// Variables
		
			int upperBound = 0;
			int lowerBound = 0;
			String userName;
			Random random = new Random();
			Scanner keyboard = new Scanner(System.in);
			
		// Obtain user input.
			
			System.out.println("This program will generate a random number in between any two numbers.");			
			System.out.println("Please enter your name");
			userName = keyboard.next();
	        System.out.println("Please enter your first number.");
	        lowerBound = keyboard.nextInt();
	        System.out.println("Please enter your second number.");
	        upperBound = keyboard.nextInt();
	        
	    // Method to ensure which number is the upper bound and which is the lower bound.  	
    	// Display user name random number.
	        
        	if (upperBound > lowerBound) {
            	int randomNumber = random.nextInt(upperBound) + lowerBound;
                System.out.println(userName);
                System.out.println("Your random number is:" + randomNumber);
                
        	} else if (upperBound < lowerBound) {
            	int randomNumber = random.nextInt(lowerBound) + upperBound;
                System.out.println(userName);
                System.out.println("Your random number is:" + randomNumber);
        	}
        	keyboard.close();
	}
}
