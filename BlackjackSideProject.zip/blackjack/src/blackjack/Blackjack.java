//Name: Karl Sidney Jr
//Last Modified: 2/25/24
//Blackjack side project
//This class has all of the rules and methods for the player and dealer

package blackjack;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import blackjack.Card.Rank;

public class Blackjack {


	// Variables
	private static final Scanner scanner = null;
	private Deck deck;
	private List<Card> playerHand;
	private List<Card> dealerHand;
	private int dealerTotal;
	private int playerTotal;

	// Get the player's hand total

public int getPlayerTotal() {
	return playerTotal;
}

	// Set the player's hand total

public void setPlayerTotal(int playerTotal) {
	this.playerTotal = playerTotal;
}

	// Get the dealer's hand total

public int getDealerTotal() {
	return dealerTotal;
}

	// Set the dealer's hand total

public void setDealerTotal(int dealerTotal) {
	this.dealerTotal = dealerTotal;
}

	//Constructor for an instance of "Blackjack" game

public Blackjack() {
	this.deck = new Deck();
	this.playerHand = new ArrayList<>();
	this.dealerHand = new ArrayList<>();
}

	// Method to start a new game

public void newGame() {
	System.out.println("***** Blackjack *****" + "\n");
	System.out.println("New Game" + "\n");
	System.out.println("Would you like to play? (y/n): " + "\n");
	Scanner scanner = new Scanner(System.in);
	char answer = scanner.nextLine().charAt(0);
	if (answer == 'y' || answer == 'Y') {
		deal();
	} else {
		endGame();
	}
}

	// Method to deal cards

public void deal() {
	dealerHand.clear();
	Card dealerCardOne = deck.dealCard();
	Card dealerCardTwo = deck.dealCard();
	dealerHand.add(dealerCardOne);
	dealerHand.add(dealerCardTwo);
	
	playerHand.clear();
	Card playerCardOne = deck.dealCard();
	Card playerCardTwo = deck.dealCard();
	playerHand.add(playerCardOne);
	playerHand.add(playerCardTwo);
	
	System.out.println("Your cards are the " + playerCardOne + " and the " + playerCardTwo + "\n");
	System.out.println("The Dealer shows " + dealerCardOne + " and one card faced down" + "\n");
	
	playerTotal = calculatePlayerTotal(playerHand);
	dealerTotal = calculateDealerTotal(dealerHand);
	System.out.println("Your total: " + playerTotal + "\n");
	System.out.println("Dealer's total: " + dealerCardOne.getValue() + "\n");
	if (playerTotal == 21) {
		win();
	}else{
		move();
		}
	}

	// Method for player's move

public void move() {
	System.out.println("Would you like to hit(H) or stay(S)?" + "\n");
	Scanner scanner = new Scanner(System.in);
	char choice = scanner.nextLine().charAt(0);
	if (choice == 'h' || choice == 'H') {
		hit();
	}
	if(choice == 's' || choice == 'S') {
		stay();
	}
}

	// Method when player decides to hit

public void hit() {
	Card newCard = deck.dealCard();
	playerHand.add(newCard);
	System.out.println("You drew: " + newCard + "\n");
	int playerTotal = calculatePlayerTotal(playerHand);
	System.out.println("Your total is: " + playerTotal + "\n");
	if (playerTotal == 21) {
		win();
	}else if(playerHand.size() == 5 && calculatePlayerTotal(playerHand) <= 21) {
		win();
	}else if(playerTotal > 21) {
		bust();
	} else {
		move();
	}
}

	// Method when player decides to stay

public void stay() {
		System.out.println("You chose to stay. It is the dealer's turn.");
			dealerMove();
		}

	// Method for dealer's move

public void dealerMove() {
	System.out.println("Dealer flips over his other card to reveal his hand: ");
	System.out.println(dealerHand.toString());
	dealerTotal = calculateDealerTotal(dealerHand);
	while (dealerTotal < playerTotal) {
	Card newCard = deck.dealCard();
	dealerHand.add(newCard);
	System.out.println("Dealer flips over his other card to reveal his hand: ");
	System.out.println(dealerHand.toString());
	System.out.println("Dealer drew: " + newCard);
	dealerTotal = calculateDealerTotal(dealerHand);
	}
	if(dealerHand.size() == 5 && calculateDealerTotal(dealerHand) <= 21) {
		dealerWin();
	}else if(dealerTotal > 21) {
		dealerBust();
	}else{
		System.out.println("The dealer chose to stay. Let's see who won!" + "\n");
		compareHands();
	}
}

	// Method to compare hands 

public void compareHands() {
	playerTotal = calculatePlayerTotal(playerHand);
	dealerTotal = calculateDealerTotal(dealerHand);
	System.out.println("Your total: " + playerTotal);
	System.out.println("Dealer's total: " + dealerTotal);
	if (playerTotal > dealerTotal) {
		win();
	}else if(playerTotal < dealerTotal) {
		dealerWin();
	}else{
		tieGame();
	}
}

	// Method for dealer's win

public void dealerWin() {
	System.out.println(dealerHand.toString());
	System.out.println("The dealer's total is: " + calculateDealerTotal(dealerHand) + "  You lose :(" + "\n");
	endOfGameAnswer();
}

	// Method for when the dealer's score goes over 21

public void dealerBust() {
	System.out.println(dealerHand.toString());
	System.out.println("The dealer's total is: " + calculateDealerTotal(dealerHand) + "\n");
	System.out.println("\n *** Bust ***" + "\n");
	win();
}

	// Method for player's win

public void win() {
	System.out.println("***** You Win! ******" + "\n");
	endOfGameAnswer();
}

	// Method in case there is a tie

public void tieGame() {
	System.out.println("***** It's a tie '-' ******" + "\n");
	endOfGameAnswer();
}

	// Method for when the player's hand goes over 21

public void bust() {
	System.out.println("*** Bust ***" + "\n");
	System.out.println("I'm sorry" + "\n");
	System.out.println( "You lose :(" + "\n");
	endOfGameAnswer();
}

// Method to see if the player would like to play again

private <Constant> void endOfGameAnswer() {
	System.out.print("Play again? (y/n) " + "\n");
	Scanner scanner = new Scanner(System.in);
	char nextMove = scanner.nextLine().charAt(0);
	if (nextMove == 'Y' || nextMove == 'y') {
		deal();
	}else{
		System.out.println("Thank you for playing!" + "\n");
		endGame();
	}
}

	// Method to end the game

public void endGame() {
	scanner.close();
	System.out.println("Program Terminated");
}

	// Method to return the cards in the player's hand

public List<Card> getplayerHand() {
	return playerHand;
}

	// Method to return the cards in the dealer's hand

public List<Card> getDealerHand() {
	return dealerHand;
}

	// Method to add a card to the player's hand

public void addCardToPlayerHand(Card card) {
	playerHand.add(card);
}

	// Method to add a care to the dealer's hand

public void addCardToDealerHand(Card card) {
	dealerHand.add(card);
}

	// Method to add up the total of the player's hand and 
	// to check if the value of an ACE needs to be changed

public int calculatePlayerTotal(List<Card> hand) {
    int total = 0;
    int aceCount = 0;
	for (Card card : hand) {
	total += card.getValue();
	if (card.getRank() == Rank.ACE) {
		aceCount++;
		}
	}
	while (total > 21 && aceCount > 0) {
		total -= 10;
		aceCount--;
	}
	return total;
}

	// Method to add up the total of the dealer's hand and return a score

public int calculateDealerTotal(List<Card> hand) {
    int total = 0;
    int aceCount = 0;
	for (Card card : hand) {
	total += card.getValue();
	if (card.getRank() == Rank.ACE) {
		aceCount++;
		}
	}
	while (total > 21 && aceCount > 0) {
	total -= 10;
		aceCount--;
	}
	return total;
	}
}