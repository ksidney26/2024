//Name: Karl Sidney Jr
//Last Modified: 2/25/24
//Blackjack side project
//This class is used to be the Deck of cards

package blackjack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import blackjack.Card.Rank;
import blackjack.Card.Suit;

public class Deck {

	private List<Card> cards;
	private List<Card> dealtCards;

	public Deck() {
		this.cards = new ArrayList<>();
		this.dealtCards = new ArrayList<>();
		initializeDeck();
		shuffleDeck();
	}

	private void initializeDeck() {
		for (Suit suit : Suit.values()) {
		for (Rank rank : Rank.values()) {
		Card card = new Card(rank, suit);
		cards.add(card);
				}
			}
		}

	private void shuffleDeck() {
		Collections.shuffle(cards);
	}

	public Card dealCard() {
		if (cards.isEmpty()) {
			return null;
	}
	Card dealtCard = cards.remove(0);
	dealtCards.add(dealtCard);
	return dealtCard;
	}

	public List<Card> getDealtCards() {
	return dealtCards;
	}

	public List<Card> getRemainingCards() {
	return cards;
	}
}
