//Name: Karl Sidney Jr
//Last Modified: 2/25/24
//Blackjack side project
//This class is used to represent the cards

package blackjack;

	public class Card {

		private Rank rank;
		private Suit suit;
		
	public Card(Rank rank, Suit suit) {
		this.rank = rank;
		this.suit = suit;
	}

	public int getValue() {
		int value = 0;
		switch (rank) {
		case ACE: value = 11; break;
		case TWO: value = 2; break;
		case THREE: value = 3; break;
		case FOUR: value = 4; break;
		case FIVE: value = 5; break;
		case SIX: value = 6; break;
		case SEVEN: value = 7; break;
		case EIGHT: value = 8; break;
		case NINE: value = 9; break;
		case TEN:
		case JACK:
		case QUEEN:
		case KING: value = 10; break;
		}
		return value;
	}

	// Override toString to display each card's information

	@Override
	public String toString() {
		String rankStr = rank.toString();
		String suitStr;
		switch (suit) {
		case CLUBS: suitStr = "♧♣Clubs♣♧";break;
		case DIAMONDS: suitStr = "♢♦Diamonds♦♢";break;
		case HEARTS: suitStr = "♡♥Hearts♥♡";break;
		case SPADES: suitStr = "♤♠Spades♠♤";break;
		default: suitStr = "";break;
		}
		return rankStr + " of " + suitStr;
	}

	public Rank getRank() {
		return this.rank;
	}
	
	enum Suit {
		CLUBS, DIAMONDS, HEARTS, SPADES
	}

	enum Rank {
		ACE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING
	}
}
