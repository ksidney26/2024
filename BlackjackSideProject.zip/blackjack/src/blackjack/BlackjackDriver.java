//Name: Karl Sidney Jr
//Last Modified: 2/25/24
//Blackjack side project

package blackjack;

public class BlackjackDriver {
	
public static void main(String[] args) {

/*
♠	Black Spade	&#9824;
♥	Black Heart	&#9829;
♣	Black Club	&#9827;
♦	Black Diamond	&#9830;
♤	White Spade	&#9828;
♡	White Heart	&#9825;
♧	White Club	&#9831;
♢	White Diamond	&#9826;
*/
//("Heart:");
System.out.println("    ♥♥♥       ♥♥♥    ");
System.out.println("  ♥♥   ♥♥   ♥♥   ♥♥  ");
System.out.println(" ♥♥     ♥♥ ♥♥     ♥♥ ");
System.out.println(" ♥♥      ♥♥♥      ♥♥ ");
System.out.println("  ♥♥             ♥♥  ");
System.out.println("    ♥♥         ♥♥    ");
System.out.println("      ♥♥     ♥♥      ");
System.out.println("        ♥♥♥♥♥        ");
System.out.println("          ♥          ");
System.out.println();

//("Club:");
System.out.println("       ♣♣♣♣♣♣♣       ");
System.out.println("      ♣♣♣♣♣♣♣♣♣      ");
System.out.println("     ♣♣♣♣♣♣♣♣♣♣♣     ");
System.out.println("      ♣♣♣♣♣♣♣♣♣      ");
System.out.println("   ♣♣♣♣♣♣♣♣♣♣♣♣♣♣♣   ");
System.out.println("  ♣♣♣♣♣♣♣♣♣♣♣♣♣♣♣♣♣  ");
System.out.println("   ♣♣♣♣♣ ♣♣♣ ♣♣♣♣♣   ");
System.out.println("        ♣♣♣♣♣        ");
System.out.println("     ♣♣♣♣♣♣♣♣♣♣♣     ");
System.out.println("\n");

//("Diamond:");
System.out.println("          ♦          ");
System.out.println("         ♦♦♦         ");
System.out.println("        ♦♦♦♦♦        ");
System.out.println("       ♦♦♦♦♦♦♦       ");
System.out.println("      ♦♦♦♦♦♦♦♦♦      ");
System.out.println("       ♦♦♦♦♦♦♦      ");
System.out.println("        ♦♦♦♦♦        ");
System.out.println("         ♦♦♦         ");
System.out.println("          ♦          ");
System.out.println();

//("Spade:");
System.out.println("         ♠♠♠         ");
System.out.println("        ♠♠♠♠♠        ");
System.out.println("       ♠♠♠♠♠♠♠       ");
System.out.println("      ♠♠♠♠♠♠♠♠♠      ");
System.out.println("     ♠♠♠♠♠♠♠♠♠♠♠     ");
System.out.println("    ♠♠♠♠♠♠♠♠♠♠♠♠♠     ");
System.out.println("   ♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠   ");
System.out.println("  ♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠♠  ");
System.out.println("   ♠♠♠♠♠ ♠♠♠ ♠♠♠♠♠   ");
System.out.println("        ♠♠♠♠♠        ");
System.out.println("     ♠♠♠♠♠♠♠♠♠♠♠     ");
System.out.println();
Blackjack game = new Blackjack();
game.newGame();
	}
}
