package moduleCLOLabTwoGameCharacter;

public class VideoGame {

}
