package moduleCLOLabTwoGameCharacter;

public class GameStudio {

}
