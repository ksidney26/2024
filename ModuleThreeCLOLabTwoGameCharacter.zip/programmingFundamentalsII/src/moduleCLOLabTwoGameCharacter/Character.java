package moduleCLOLabTwoGameCharacter;

public class Character {

}
