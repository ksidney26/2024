// Name: Karl Sidney 
// Last Modified: 1/27/24
// This program is for Module One and will calculate the fuel efficiency of a car in miles per gallon.
package LabTwo;

import java.util.Scanner;

public class ModuleOneMPG {

	public static void main(String[] args) {

	// Variables.
		
		int milesDriven = 0;
		int gasConsumed = 0;
		int milesPerGallon = 0;
		Scanner keyboard = new Scanner(System.in);
		
	// Obtain user input.
		
		System.out.println("This program will calculate the fuel efficiency of your car in MPG.");
		System.out.println("Please enter the number of miles driven.");
		milesDriven = keyboard.nextInt();
		System.out.println("Please enter the amount of fuel consumed in gallons.");
		gasConsumed = keyboard.nextInt();
		
	// Calculate fuel efficiency.
		
		milesPerGallon = (milesDriven/gasConsumed);
		
	// Display results.
		
		System.out.println("You drove " + milesDriven + (" miles."));
		System.out.println("You used " + gasConsumed + (" gallons."));
		System.out.println("Your vehicle gets approximately " + milesPerGallon + "MPG.");
		keyboard.close();
	}
}
