package moduleTwoLabSport;

import java.util.Scanner;

public class SportDriver {
	
	public static void main(String[] args) {
		
		//Variables
		
		Sport sportOne = new Sport();
		String sportOneName;
		int sportOneRoster;
		double sportOneWins;
		int sportOneLosses;
		
		//Create a new scanner for user input
		
		Scanner keyboard = new Scanner(System.in);
		
		//Prompt user to input team info
		
		System.out.println("Please answer the following questions about your favorite team");
		System.out.println("What is the name your team?");
		sportOneName = keyboard.next();
		sportOne.setName(sportOneName);
		
		//Prompt roster Size
		
		System.out.println("How many players are on this team?");
		sportOneRoster = keyboard.nextInt();
		sportOne.setNumberOfPlayers(sportOneRoster);
		
		//Prompt number of wins
		
		System.out.println("How many wins do they have this season?");
		sportOneWins = keyboard.nextDouble();
		sportOne.setSeasonWins(sportOneWins);

		//Prompt number of Losses
		
		System.out.println("How many losses do they have?");
		sportOneLosses = keyboard.nextInt();
		sportOne.setSeasonLosses(sportOneLosses);
	
		//Now display the team with the updated data
		
		System.out.print(sportOne.SportInfo());
		keyboard.close();
		}
	}