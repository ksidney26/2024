// Name: Karl Sidney 
// Last Modified: 2/8/24
// This Java class is going to be used to encapsulate the concept of a sports team.

package moduleTwoLabSport;

public class Sport {

	// Variables

	private String Name;
	private int NumberOfPlayers;
	private double SeasonWins;
	private int SeasonLosses;
	private double WinLossPercentage;
	
	// Return the name
	 
	public String getName() {
		return Name;
	}
	
	// Return the numberOfPlayers
	 
	public int getNumberOfPlayers() {
		return NumberOfPlayers;
	}
	
	// Return the seasonWins
	 
	public double getSeasonWins() {
		return SeasonWins;
	}
	
	// Return the seasonLosses
	 
	public int getSeasonLosses() {
		return SeasonLosses;
	}
	
	// Set the name

	public void setName(String name) {
		Name = name;
	}
	
	// Set the numberOfPlayers
	 
	public void setNumberOfPlayers(int numberOfPlayers) {
		NumberOfPlayers = numberOfPlayers;
	}
	
	// Set the seasonWins
	 
	public void setSeasonWins(double seasonWins) {
		SeasonWins = seasonWins;
	}
	
	// Set the SeasonLosses
	 
	public void setSeasonLosses(int seasonLosses) {
		SeasonLosses = seasonLosses;
	}
	
	// Default Constructor
	
	public Sport() {
		this.Name = "Unknown Name.";
		this.NumberOfPlayers = 0;
		this.SeasonWins = 0;
		this.SeasonLosses = 0;
	}
	
	// Constructor
	
	public Sport(String name, int numberOfPlayers, double seasonWins, int seasonLosses, double getwinLossPercentage) {
		super();
		Name = name;
		NumberOfPlayers = numberOfPlayers;
		SeasonWins = seasonWins;
		SeasonLosses = seasonLosses;
	}
	
	// Method to calculate win/loss percentage
	
	public double getWinLossPercentage() {
		WinLossPercentage = SeasonWins/SeasonLosses;
		return WinLossPercentage;
	}

	// Method to display team details
	
	public String SportInfo() {
		String myReturn = "";
		myReturn = "Name: " + this.getName() + "\n";
		myReturn += "NumberOfPlayers: " + this.getNumberOfPlayers() + "\n";
		myReturn += "SeasonWins: " + this.getSeasonWins() + "\n";
		myReturn += "SeasonLosses: " + this.getSeasonLosses() + "\n";
		myReturn += "WinLossPercentage: " + this.getWinLossPercentage() + "\n";
		return myReturn;
	}
}
	