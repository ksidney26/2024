//Name: Karl Sidney 
//Last Modified: 2/21/24
//This Java class is used to demonstrate the driver for module 3 "Employee Lab".

package moduleThreeLabEmployee;

import java.util.Scanner;

public class EmployeeDriver {

    public static void main(String[] args) {

    // Variables

    String myUserID;
    String myFirstName;
    String myLastName;

    // Initiate a scanner

    Scanner keyboard = new Scanner(System.in);

    // Initiate "Benefits" object with employee's benefits

    Benefits myBenefits = new Benefits("Health", 500, "USAA");

    // Initiate "Address" object with employee's address

    Address myAddress = new Address("1375 E. Bitters", "San Antonio, ", "Texas, ", "78232." + "\n");

    // Beginning of user prompts

    System.out.println("Welcome to the Info System" + "\n");

    System.out.println("Please enter your USER ID" + "\n");
    myUserID = keyboard.next();

    System.out.println("\n" + "Please enter your first name" + "\n");
    myFirstName = keyboard.next();

    System.out.println("\n" + "Please enter your last name" + "\n");
    myLastName = keyboard.next();

    // Initiate "Employee" object

    Employee myEmployee = new Employee(myUserID, myFirstName, myLastName, myBenefits, myAddress);

    // Print employee's data

    System.out.print(myEmployee.printEmployeeInfo());
    
    // Close keyboard

    keyboard.close();
    }
}
