//Name: Karl Sidney 
//Last Modified: 2/21/24
//This Java class is used to hold the information for an employee's address.

package moduleThreeLabEmployee;

public class Address {

	//Variables

	private String street;
	private String city;
	private String state;
	private String zip;

	//Get street

	public String getStreet() {
		return street;
	}

	// Get city
	
	public String getCity() {
		return city;
	}

	// Get state

	public String getState() {
		return state;
	}

	// Get zip

	public String getZip() {
		return zip;
	}

	// Set street

	public void setStreet(String street) {
		this.street = street;
	}

	// Set city

	public void setCity(String city) {
		this.city = city;
	}

	// Set state

	public void setState(String state) {
		this.state = state;
	}

	// Set zip

	public void setZip(String zip) {
		this.zip = zip;
	}

	// Parameterized constructor

	public Address(String street, String city, String state, String zip) {
		super();
		this.street = street;
		this.city = city;
		this.state = state;
		this.zip = zip;
	}

	// Default constructor 

	public Address() {
		this.street = "Unknown Address";
		this.city = "Unknown City";
		this.state  = "Unknown State";
		this.zip  = "Unknown Zip";
	}

	// Copy constructor

	public Address(Address pAdd) {
		this.street = pAdd.street;
		this.city = pAdd.city;
		this.state = pAdd.state;
		this.zip = pAdd.zip;	
	}

	// Print info method

	public String PrintAddressInfo() {		
		String myReturn = "";		
		myReturn += getStreet() + "\n";
		myReturn += getCity() + "\n";
		myReturn += getState() + "\n";
		myReturn +=	getZip() + "\n"; 		
		return myReturn;
	}

	@Override
	public String toString() {
		return  "Address: " + street + "\n" + city + state + zip + "\n";
	}
}