//Name: Karl Sidney 
//Last Modified: 2/21/24
//This Java class is used to hold the information for an employee's benefits.

package moduleThreeLabEmployee;

import java.text.NumberFormat;

public class Benefits {

	// Variables

	private String type;
	private float cost;
	private String provider;

	// Get type

	public String getType() {
		return type;
	}

	// Get cost

	public float getCost() {
		return cost;
	}

	// Get provider

	public String getProvider() {
		return provider;
	}

	// Set type

	public void setType(String type) {
		this.type = type;
	}

	// Set cost

	public void setCost(float cost) {
		this.cost = cost;
	}

	// Set provider

	public void setProvider(String provider) {
		this.provider = provider;
	}
	
	// Parameterized constructor

	public Benefits(String type, float cost, String provider) {
		super();
		this.type = type;
		this.cost = cost;
		this.provider = provider;
	}

	//Default constructor

	public Benefits() {
		this.type = "Unknown type";
		this.cost = 0;
		this.provider = "Unknown Provider";
	}

	//Copy constructor

	public Benefits(Benefits pAdd) {
		this.type = pAdd.type;
		this.cost = pAdd.cost;
		this.provider = pAdd.provider;	
	}

	// Info method

	public String PrintBenefitsInfo() {		
		String myReturn = "Employee Benefits" + "\n";		
		myReturn += getType() + ", " + getCost() + ", " + getProvider();
		return myReturn;
	}

	 @Override
	 public String toString() {
		 NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
	     return  "\n" + "Benefit Type: " + type + "\n" + "Cost: " + currencyFormatter.format(cost) 
	     + "\n"+ "Provider: " + provider + "\n";
	 }
}			