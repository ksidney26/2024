//Name: Karl Sidney 
//Last Modified: 2/21/24
//This Java class is used to hold the information for an employee.

package moduleThreeLabEmployee;

public class Employee {

	// Variables

	private String userID;
	private String firstName;
	private String lastName;
	private Benefits employeeBenefits;
	private Address employeeAddress;

	// Get employee ID

	public String getuserID() {
		return userID;
	}

	// Get first name

	public String getFirstName() {
		return firstName;
	}

	// Get last name

	public String getLastName() {
		return lastName;
	}

	// Get employee address

	public Address getEmployeeAddress() {
		return employeeAddress;
	}

	// Get employee benefits

	public Benefits getEmployeeBenefits() {
		return employeeBenefits;
	}

	// Set user ID

	public void setUserID(String userID) {
			this.userID = userID;
	}

	// Set first name

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	// Set last name

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	// Set employee's address

	public void setEmployeeAddress(Address employeeAddress) {
		this.employeeAddress = new Address(employeeAddress);
	}

	// Set employee's benefits

	public void setEmployeeBenefits(Benefits employeeBenefits) {
		this.employeeBenefits = new Benefits (employeeBenefits);
	}

	// Parameterized constructor

	public Employee(String employeeID, String firstName, String lastName, Benefits employeeBenefits, Address employeeAddress) {
		this.userID = employeeID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.employeeBenefits = new Benefits(employeeBenefits);
		this.employeeAddress = new Address(employeeAddress);
	}

	//Default constructor

	public Employee() {
		this.userID = "Unknown ID";
		this.firstName = "Unknown first name";
		this.lastName = "Unknown last name";
		this.employeeBenefits = new Benefits();
		this.employeeAddress = new Address();
	}

	//Copy constructor

	public Employee(Employee pEmployee) {
		this.userID = pEmployee.userID;
		this.firstName = pEmployee.firstName;
		this.lastName = pEmployee.lastName;
		this.employeeBenefits = new Benefits(pEmployee.getEmployeeBenefits());
		this.employeeAddress = new Address(pEmployee.getEmployeeAddress());
	}

	// Print info method

	public String printEmployeeInfo() {
		String myReturn = "";		
		myReturn += "UserID: " + getuserID() + "\n" + "First Name: " + getFirstName() + "\n" + "Last Name: " +  getLastName() + "\n";
		myReturn += getEmployeeBenefits() + "\n";
		myReturn += getEmployeeAddress();
		return myReturn;
	}

	 @Override
	 public String toString() {
		return  "\tUser ID: " + userID + "\tFirst Name: " + firstName + "\tLast Name: " + lastName + "\n"
	    + "tBenefits: " + employeeBenefits + "\n" + "tAddress" + employeeAddress;
	 }
}  