// Name: Karl Sidney 
// Last Modified: 1/25/24
// This program is for Module One and will simulate get the total of a cash register with user input.

package LabTwo;
import java.util.Scanner;

public class ModuleOneCashRegister {

	public static void main(String[] args) {

		//variables
				int bill20 = 0;
				int bill10 = 0;
				int bill5 = 0;
				int bill1 = 0;
				int quarters = 0;
				int dimes = 0;
				int nickels = 0;
				int pennies = 0;
				double sumOfChange = 0.0;
				Scanner keyboard = new Scanner(System.in);

		//obtain user input
				System.out.println("This program will help you count the cash in your register");
		        System.out.println("Please enter the number of each currency type");
		        System.out.println("Enter the number of 20's.");
		        bill20= keyboard.nextInt();

		        System.out.println("Enter the number of 10's.");
		        bill10 = keyboard.nextInt();

		        System.out.println("Enter the number of 5's.");
		        bill5 = keyboard.nextInt();

		        System.out.println("Enter the number of 1's.");
		        bill1 = keyboard.nextInt();

		        System.out.println("Enter the number of quarters.");
		        quarters = keyboard.nextInt();

		        System.out.println("Enter the number of dimes.");
		        dimes = keyboard.nextInt();

		        System.out.println("Enter the number of nickels.");
		        nickels = keyboard.nextInt();

		        System.out.println("Enter the number of pennies.");
		        pennies = keyboard.nextInt();

		//arithmetic for sum		
				sumOfChange = (bill20 * 20) + (bill10 * 10) + (bill5 * 5) + bill1 + (quarters * 0.25) + (dimes * 0.10) + (nickels * 0.05) + (pennies * 0.01);

		//display results
		        System.out.println("Number of 20's " + ("$") + (bill20 * 20));
		        System.out.println("Number of 10's " + ("$") + (bill10 * 10));
		        System.out.println("Number of 5's " + ("$") + (bill5 * 5));
		        System.out.println("Number of 1's " + ("$") + (bill1 * 1));
		        System.out.println("Number of Quarters = " + ("$") + (quarters * 0.25));
		        System.out.println("Number of Dimes = " + ("$") + (dimes * 0.10));
		        System.out.println("Number of Nickels = " + ("$") + (nickels * 0.05));
		        System.out.println("Number of Pennies = " + ("$") + (pennies * 0.01));
		        System.out.println("You have $" + sumOfChange + " in the register");

		        keyboard.close();
	}
}