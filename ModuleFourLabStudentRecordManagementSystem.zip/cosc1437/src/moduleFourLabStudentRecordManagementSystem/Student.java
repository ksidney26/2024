//Name: Karl Sidney 
//Last Modified: 3/7/24
//This Java class is used to hold a Student's information for the "Student Record Management System" Lab.

package moduleFourLabStudentRecordManagementSystem;

	public class Student {

	// Variables

	private String firstName;
	private String lastName;
	private int studentID;
	private String course;
	private int yearOfStudy;
	
	// Primary constructor

	public Student(String firstName, String lastName, int studentID, String course, int yearOfStudy) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.studentID = studentID;
		this.course = course;
		this.yearOfStudy = yearOfStudy;
	}

	// Default constructor

	public Student() {
		this.firstName = "Unknown first name";
		this.lastName = "Unknown last name";
		this.studentID = 0000;
		this.course = "Unknown Course";
		this.yearOfStudy = 0000;
	}

	// Copy constructor

	public Student(Student pStudent){
		this.firstName = pStudent.firstName;
		this.lastName = pStudent.lastName;
		this.studentID = pStudent.studentID;
		this.course = pStudent.course;
		this.yearOfStudy = pStudent.yearOfStudy;
	}

	// Getter for student class

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public int getStudentID() {
		return studentID;
	}

	public String getCourse() {
		return course;
	}

	public int getYearOfStudy() {
		return yearOfStudy;
	}

	// Setters for student class

	public void setFirstName(String firstName ) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public void setYearOfStudy(int yearOfStudy) {
		this.yearOfStudy = yearOfStudy;
	}

	// Display student's info

	public String toString() {
		String description; 
		description = firstName + " " + lastName + "\n";
		description += "Student ID: " + " " + studentID + "\n";
		description += "Courses: " + course + "\n";
		description += "Year of Study: " + yearOfStudy;
		return description;
	}
}