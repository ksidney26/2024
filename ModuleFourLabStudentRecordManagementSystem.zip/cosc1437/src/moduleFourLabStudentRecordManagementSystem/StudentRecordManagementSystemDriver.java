//Name: Karl Sidney 
//Last Modified: 3/7/24
//This Java class is the Driver for the "Student Record Management System" lab.
//Will create an ArrayList, add students, then print out their info.

package moduleFourLabStudentRecordManagementSystem;

import java.util.ArrayList;

public class StudentRecordManagementSystemDriver {

	public static void main(String[] args) {

	// Create an ArrayList
	ArrayList<Student> StudentRecords = new ArrayList<Student>();

	// Adding new students to ArrayList
	StudentRecords.add(new Student("Chistopher", "Ayala", 1001, "Medical Terminology", 3));
	StudentRecords.add(new Student("Katie", "Combs", 1002, "Nursing", 2));
	StudentRecords.add(new Student("Nathan", "Estrada", 1003, "Engineering", 1));
	StudentRecords.add(new Student("Karl", "Sidney", 1004, "Mathematics", 4));
	StudentRecords.add(new Student("Taylor", "Wells", 1005, "Physics", 4));

	// Creating a new student and adding them to the ArrayList with missing information
	Student nStudent = new Student();
	nStudent.setFirstName("Erik"); 
	nStudent.setLastName("Dober");
	nStudent.setCourse("Pharmacology");
	StudentRecords.add(nStudent);

	// Print out ArrayList with all students and their information
	displayAllStudents(StudentRecords);

	}

	// Display all students method
	public static void displayAllStudents(ArrayList<Student>studentRecords) {
	for (Student myStudent : studentRecords) {
			System.out.println("\n ");
			System.out.println(myStudent.toString());
			}
		}
	}