//Name: Karl Sidney 
//Last Modified: 2/10/24
//This Java class is going to be used to gather information and create a simulated vehicle.

package moduleTwoLabCar;

public class Car {

	// Variables

	private String brand;
	private String model;
	private int year;
	private double mileage;
	
	//return the brand

	public String getBrand() {
		return brand;
	}

	//return the model
	
	public String getModel() {
		return model;
	}
		
	//return the year
		
	public int getYear() {
		return year;
	}
	
	//return the mileage
	
	public double getMileage() {
		return mileage;
	}
	
	//set the brand
	
	public void setBrand(String brand) {
		this.brand = brand;
	}

	//set the model
	
	public void setModel(String model) {
		this.model = model;
	}

	//set the year
	
	public void setYear(int year) {
		this.year = year;
	}

	//set the mileage
	
	public void setMileage(double mileage) {
		this.mileage = mileage;
	}
	
	// Default Constructor
	
	public Car() {
		this.brand = "Brand unknown.";
		this.model = "Model unknown.";
		this.year = 0;
		this.mileage = 0.0;
	}
	
	// Constructor

	public Car(String brand, String model, int year, double mileage) {
		super();
		this.brand = brand;
		this.model = model;
		this.year = year;
		this.mileage = mileage;
	}
	
	// Method for adding number of miles driven

	public double Drive(double milesDriven) {
		this.setMileage(milesDriven + mileage);
		return mileage;
	}

	// Method to display team details
	
	public String CarInfo() {
		String myReturn = "";
		myReturn = "Brand: " + this.getBrand() + "\n";
		myReturn += "Model: " + this.getModel() + "\n";
		myReturn += "Year: " + this.getYear() + "\n";
		myReturn += "Mileage: " + this.getMileage() + "mi" + "\n";
		return myReturn;
	}
}
