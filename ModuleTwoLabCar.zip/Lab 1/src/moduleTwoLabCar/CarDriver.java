package moduleTwoLabCar;

import java.util.Scanner;

public class CarDriver {

	public static void main(String[] args) {
	
		//Variables
		
	String myBrand;
	String myModel;
	int myYear;
	double myMileage;
	double myMilesDriven;
	Car myCar = new Car();
				
	//Create a new scanner for user input
				
	Scanner keyboard = new Scanner(System.in);
				
	//Prompt user to input car's brand
	
	System.out.println("Please enter the Make of your vehicle...");
	myBrand = keyboard.next();
	myCar.setBrand(myBrand);
	
	//Prompt user to input car's model
	
	System.out.println("Please enter the Model...");
	myModel = keyboard.next();
	myCar.setModel(myModel);
	
	//Prompt user to input car's year
	
	System.out.println("Please enter the Year...");
	myYear = keyboard.nextInt();
	myCar.setYear(myYear);
	
	//Prompt user to input car's mileage
	
	System.out.println("Please enter the current Mileage...");
	myMileage = keyboard.nextDouble();
	myCar.setMileage(myMileage);
	
	// Display the user's car info
	
	System.out.print(myCar.CarInfo());
	
	// Prompt user to enter a number of miles to drive the car
	
	System.out.println("Enter the number of miles you just drove");
	myMilesDriven = keyboard.nextDouble();
	
	// Uses method Drive to add the additional miles driven to the overall mileage
	
	myCar.Drive(myMilesDriven);
	System.out.print(myCar.CarInfo());
	keyboard.close();
	}
}
