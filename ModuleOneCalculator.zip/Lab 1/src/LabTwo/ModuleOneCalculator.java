// Name: Karl Sidney 
// Last Modified: 1/27/24
// This program is for Module One and will perform several calculations based on two numbers given by the user.

package LabTwo;

import java.util.Scanner;

public class ModuleOneCalculator {

	public static void main(String[] args) {

		// Variables.
		
			double numberOne = 0;
			double numberTwo = 0;
			double sum = 0;
			double difference = 0;
			double product = 0;
			double quotientOne = 0.0;
			double quotientTwo = 0.0;
			String userName;
			Scanner keyboard = new Scanner(System.in);
			
		// Obtain user input.
			
			System.out.println("This program will perform several calculations based on two numbers you provide.");		
			System.out.println("Including addition, subtraction, multiplication, and division.");
			System.out.println("Please enter your name.");
			userName = keyboard.next();
	        System.out.println("Please enter your first X value.");
	        numberOne = keyboard.nextDouble();
	        System.out.println("Please enter your Y value.");
	        numberTwo = keyboard.nextDouble();
	        
		// Perform operations.

	       sum = (numberOne + numberTwo);
	       product = (numberOne * numberTwo);
	       difference = Math.abs(numberOne - numberTwo);
	       quotientOne = (numberOne / numberTwo);
	       quotientTwo = (numberTwo / numberOne);
	        
		// Display results.
	       
           System.out.println(userName + ":");
	       System.out.println("The sum of X and Y is: " + sum);
	       System.out.println("The difference between X and Y is: " + difference);
	       System.out.println("The product of X and Y is: " + product);
	       System.out.println("The quotient of X divided by Y is: " + quotientOne + (" with a remainder of ") + (numberOne % numberTwo));
	       System.out.println("The quotient of Y divided by X is: " + quotientTwo + (" with a remainder of ") + (numberTwo % numberOne));
	       keyboard.close();
	}

}
