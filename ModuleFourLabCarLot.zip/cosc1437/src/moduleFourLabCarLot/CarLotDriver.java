//Name: Karl Sidney Jr
//Last Modified: 3/9/24
//This Java class is for module 4 lab "Car Lot" and will simulate a management system for a car lot.

package moduleFourLabCarLot;

import java.util.ArrayList;
import java.text.NumberFormat;

public class CarLotDriver {

	public static void main(String[] arg) {

	System.out.println("Module Four Lab Car Lot."+"\n");
		
	// Create new ArrayList and pre-populate with five vehicles

	ArrayList<Car> inventory = new ArrayList<Car>();
	inventory.add(new Car(" Ford ", " Escape ", " 2015 ", 12999));
	inventory.add(new Car(" Toyota ", " Tundra ", " 2017 ", 29999));
	inventory.add(new Car(" Mitsubishi ", " Lancer ", " 2019 ", 32999));
	inventory.add(new Car(" GMC ", " Terrain ", " 2012 ", 14999));
	inventory.add(new Car(" Porsche ", " Panamera ", " 2020 ", 39999));

	// Display current inventory and calculate the total cost

	System.out.println("Here's your inventory: "+"\n");
	displayInventory(inventory);
	System.out.println("\n"+"Calculating total value: "+"\n");
	calculateTotalValue(inventory);
	System.out.println("End of program");
	}

	// Method for displaying inventory

	public static void displayInventory(ArrayList<Car>inventory) {
			System.out.println(inventory.toString());
		}

	// Method for calculation total inventory cost
	
	public static void calculateTotalValue(ArrayList<Car>inventory) {
	NumberFormat fmt = NumberFormat.getCurrencyInstance();
	double totalCost = 0.0;
	for(Car Inventory : inventory) {
		System.out.println(Inventory.getModel()+" + ");
		totalCost += Inventory.getPrice();
		System.out.println(fmt.format(totalCost));
		}
	String report = "\n" + "▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\n";
	report += "▀▀▀▀▀▀▀▀▀▀ Total equity of inventory:" + fmt.format(totalCost) + " ▀▀▀▀▀▀▀▀▀▀\n";
	report += "▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀\n";
	System.out.print(report);
	}
}