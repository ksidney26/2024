//Name: Karl Sidney Jr
//Last Modified: 3/9/24
//This Java class is for module 4 lab "Car Lot" and will simulate a management system for a car lot.

package moduleFourLabCarLot;

import java.text.NumberFormat;

public class Car {

	// Variables

	private String make;
	private String model;
	private String year;
	private double price;

	// For price format

	NumberFormat formatter = NumberFormat.getCurrencyInstance();

	// Primary constructor

 	public Car(String make, String model, String year, double price) {
 		this.make = make;
 		this.model = model;
 		this.year = year;
 		this.price = price;
 	}

 	// Default constructor

 	public Car() {
 		this.make = "Unknown Make";
 		this.model = "Unknown model";
 		this.year = "Unknown price";
 		this.price = 00.00;
 	}

 	// Copy constructor

 	public Car(Car pCar) {
 		this.make = pCar.make;
 		this.model = pCar.model;
 		this.year = pCar.year;
 		this.price = pCar.price;
 	}
 	
 	// Overloading constructor
 	
 	public Car (String me) {
 		make = me;
 		model = "Unknown model";
 		year = "Unknown price";
 		price = 00.00;
 	}
 	
 	// Overloading constructor
 	
 	public Car (String me, String ml) {
 		make = me;
 		model = ml;
 		year = "Unknown Year";
 		price = 00.00;
 	}
 	
 	// Overloading constructor
 	public Car (String me, String ml, String yr) {
 		make = me;
 		model = "Unknown model";
 		year = yr;
 		price = 00.00;
 	}
 	
 	//Get car make

	public String getMake() {
		return make;
	}

	// Get car model

	public String getModel() {
		return model;
	}

	// Get car year

	public String getYear() {
		return year;
	}

	// Get car price

	public double getPrice() {
		return price;
	}

	// Set car make
	
	public void setMake(String make) {
		this.make = make;
	}

	// Set car model

	public void setModel(String model) {
		this.model = model;
	}

	// Set car year

	public void setYear(String year) {
		this.year = year;
	}
	
	// Set car price
	
	public void setPrice (double price) {
		this.price = price;
	}

	// Method to print out car's information

	public String carInfo() {
		String myReturn = "";
		myReturn += this.getYear() + this.getMake() + this.getModel() + "  \n" + formatter.format(this.getPrice()) + "\n";
		return myReturn;
	}

	//To String method for car's information

	 @Override
	 public String toString() {
		return this.getYear() + this.getMake() + this.getModel() + "  \n" + formatter.format(this.getPrice()) + "  \n";
	 }
}
