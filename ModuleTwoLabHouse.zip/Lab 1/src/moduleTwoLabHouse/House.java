//Name: Karl Sidney 
//Last Modified: 2/11/24
//This Java class is used to simulate and hold the variables of a house.
 
package moduleTwoLabHouse;

import java.text.NumberFormat;

	public class House {
		
		// Variables
		
		private String address;
		private int numBedrooms;
		private double numBathrooms;
		private double price;
		private int squareFeet;
		private double pricePerSqFt;
		
		// For price format
		
		NumberFormat formatter = NumberFormat.getCurrencyInstance();
		
		// Get address of house
		
		public String getAddress() {
			return address;
		}
		
		// Get number of bedrooms
		
		public int getNumBedrooms() {
			return numBedrooms;
		}
		
		// Get number of bathrooms
		
		public double getNumBathrooms() {
			return numBathrooms;
		}
		
		// Get price of house
		
		public double getPrice() {
			return price;
		}
		
		// Get the square footage of house
		
		public int getSquareFeet() {
			return squareFeet;
		}
		
		// Get price per square footage of a house
		
		public double getPricePerSqFt() {
			return this.pricePerSqFt = calculatePricePerSqFt();
		}
		
		// Set address of house
		
		public void setAddress(String address) {
			this.address = address;
		}
		
		// Set number of bedrooms
		
		public void setNumBedrooms(int numBedrooms) {
			this.numBedrooms = numBedrooms;
		}
		
		// Set number of bathrooms
		
		public void setNumBathrooms(double numBathrooms) {
			this.numBathrooms = numBathrooms;
		}
		
		// Set price of house
		
		public void setPrice(double price) {
			this.price = price;
		}
		
		// Set square footage
		
		public void setSquareFeet(int squareFeet) {
			this.squareFeet = squareFeet;
		}
		
		// Set the price per square footage
		
		public void setPricePerSqFt(double pricePerSqFt) {
			this.pricePerSqFt = calculatePricePerSqFt();
		}
		
		// Method for calculating price per square foot
		
		public double calculatePricePerSqFt() {
			pricePerSqFt = this.price/this.squareFeet;
			return pricePerSqFt;
		}
		
		// Default constructor
		
		public House() {
			this.address = "address not provided";
			this.numBedrooms = 0;
			this.numBathrooms = 0.0;
			this.price = 0.0;
			this.squareFeet = 0;
		}
		
		// Parameterized constructor
		
		public House(String address, int numBedrooms, double numBathrooms, double price, int squareFeet, double pricePerSqFt)
		{
			super();
			this.address = address;
			this.numBedrooms = numBedrooms;
			this.numBathrooms = numBathrooms;
			this.price = price;
			this.squareFeet = squareFeet;
			this.pricePerSqFt = pricePerSqFt;
		}
		
		public String HouseInfo() {
			String myReturn = "";
			myReturn = "Address: " + this.getAddress() + "\n";
			myReturn += "Number of bedrooms: " + this.getNumBedrooms() + "\n";
			myReturn += "Number of bathrooms: " + this.getNumBathrooms() + "\n";
			myReturn += "Price " + formatter.format(this.getPrice()) + "\n";
			myReturn += "Square footage: " + this.getSquareFeet() + "\n";
			myReturn += "Price per square feet" + formatter.format(this.getPricePerSqFt()) + "\n";
			return myReturn;
		}
}