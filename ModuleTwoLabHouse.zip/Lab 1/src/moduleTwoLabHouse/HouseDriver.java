//Name: Karl Sidney 
//Last Modified: 2/11/24
//This Java class is the driver for the House class object.

package moduleTwoLabHouse;

import java.util.Scanner;

public class HouseDriver {

	public static void main(String[] args) {
		
		// Variables
		
		String myAddress;
		int myBedrooms;
		double myBathrooms;
		double myPrice;
		int mySquareFootage;
		House myHouse = new House();
		
		//Create a new scanner for user input
		
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("This program will be used to collect the details of your house.");
		
		// Prompt the use for the address of their house
		
		System.out.println("First, what is the address of your house?");
		myAddress = keyboard.next();
		myHouse.setAddress(myAddress);
		
		// Prompt the use for the number of bedrooms
		
		System.out.println("How many bedrooms does it have?");
		myBedrooms = keyboard.nextInt();
		myHouse.setNumBedrooms(myBedrooms);
		
		// Prompt the user for the number of bathrooms
		
		System.out.println("How many bathrooms does it have?");
		myBathrooms = keyboard.nextDouble();
		myHouse.setNumBathrooms(myBathrooms);
		
		// Prompt the user for the price
		
		System.out.println("What is the current price of your housee?");
		myPrice = keyboard.nextDouble();
		myHouse.setPrice(myPrice);
		
		// Prompt the user for the square footage
		
		System.out.println("What is the square footage of you house?");
		mySquareFootage = keyboard.nextInt();
		myHouse.setSquareFeet(mySquareFootage);
		
		// Display users house information
		
		System.out.print(myHouse.HouseInfo());
		
		// Prompt the user to update the price of the house
		
		System.out.println("What is the updated price on your house?");
		myPrice = keyboard.nextDouble();
		myHouse.setPrice(myPrice);
		
		//Display updated price
		
		System.out.print(myHouse.HouseInfo());
		keyboard.close();
	}
}