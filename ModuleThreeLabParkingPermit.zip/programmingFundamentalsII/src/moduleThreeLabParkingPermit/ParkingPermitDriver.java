//Name: Karl Sidney 
//Last Modified: 2/23/24
//This Java class is used for the driver on the ParkingPermit lab.

package moduleThreeLabParkingPermit;

import java.util.Scanner;

public class ParkingPermitDriver {

	public static void main(String[] args) {

    // Variables

    String myFirstName;
    String myLastName;
    String myStreet;
    String myCity;
    String myState;
    String myZip;
    String myYear;
    String myMake;
    String myModel;

    // Initiate a scanner

    Scanner keyboard = new Scanner(System.in);
    
    // Create instance for header

    System.out.println(Header.PrintHeader());

    // Beginning of user prompts

    System.out.println("\n" + "Please enter your first name" + "\n");
    myFirstName = keyboard.nextLine();

    System.out.println("\n" + "Please enter your last name" + "\n");
    myLastName = keyboard.nextLine();
 
    System.out.println("\n" + "Please enter your street name and number" + "\n");
    myStreet = keyboard.nextLine();

    System.out.println("\n" + "Please enter the city" + "\n");
    myCity = keyboard.nextLine();

    System.out.println("\n" + "State..."+ "\n");
    myState = keyboard.nextLine();

    System.out.println("\n" + "Zip Code..." + "\n");
    myZip = keyboard.nextLine();

    // Prompt user for vehicle information

    System.out.println("\n" + "Vehicle Information");
    System.out.println("\n" + "Year of your vehicle?" + "\n");
    myYear = keyboard.nextLine();

    System.out.println("\n" + "Make?" + "\n");
    myMake = keyboard.nextLine();

    System.out.println("\n" + "Model?" + "\n");
    myModel = keyboard.nextLine();

    // Initiate "Address" object with the provided info

    Address myAddress = new Address(myStreet, myState, myCity, myZip);

    // Initiate "ParkingPermit" object with the provided info

    ParkingPermit myPermit = new ParkingPermit();
    myPermit.setCarYear(myYear);
    myPermit.setcarMake(myMake);
    myPermit.setCarModel(myModel);

    // Initiate "Student" object fill in the rest

    Student myStudent = new Student(myFirstName, myLastName, myAddress, myPermit);

    // Display all of the student's information

    System.out.print(myStudent.studentInfo());

    // Close keyboard and close program

    keyboard.close();
    System.out.println("\n" + Header.PrintFooter());
	}
}
