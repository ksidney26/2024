//Name: Karl Sidney 
//Last Modified: 2/23/24
//This Java class is used to hold the information about a student.

package moduleThreeLabParkingPermit;

public class Student {

	// Variables

	private String firstName;
	private String lastName;
	public Address address;
	public ParkingPermit permit;

	// Primary constructor

	public Student(String firstName, String lastName, Address address, ParkingPermit permit) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = new Address(address);
		this.permit = new ParkingPermit(permit);
	}

	// Default constructor

	public Student() {
		this.firstName = "Unknown first name";
		this.lastName = "Unknown last name";
		this.address = new Address();
		this.permit = new ParkingPermit();
	}

	// Copy constructor

	public Student(Student pStudent){
		this.firstName = pStudent.firstName;
		this.lastName = pStudent.lastName;
		this.address = new Address(pStudent.address);
		this.permit = new ParkingPermit(pStudent.permit);
	}
	
	// Get first name

	public String getFirstName() {
		return firstName;
	}

	// Get last name

	public String getLastName() {
		return lastName;
	}

	// Get address

	public Address getAddress() {
		return address;
	}

	// Get student permit ID

	public ParkingPermit getPermit() {
		return permit;
	}

	// Set first name

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	// Set last name

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	// Display student info

	public String studentInfo() {
		String myReturn = "";
		myReturn += this.getFirstName() + " " + this.getLastName() + "\n";
		myReturn += this.getAddress() + "\n";
		myReturn += this.getPermit() + "\n";
		return myReturn;
	}

	 @Override
	 public String toString() {
		return firstName + " " + lastName+ "\n"
		+ address + "\n" + permit;
	 }
}