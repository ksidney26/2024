//Name: Karl Sidney 
//Last Modified: 2/23/24
//This Java class is used to hold the information for a parking permit.

package moduleThreeLabParkingPermit;

import java.util.Random;

public class ParkingPermit {

	// Variables

	private int permitNum;
    private String carYear;
    private String carMake;
    private String carModel;
    
    
 // Primary constructor

 	public ParkingPermit(int permitNum, String carYear, String carMake, String carModel) {
 		super();
 		this.permitNum = getPermitNum();
 		this.carYear = carYear;
 		this.carMake = carMake;
 		this.carModel = carModel;
 	}

 	// Default constructor

 	public ParkingPermit() {
 		this.permitNum = 0000;
 		this.carYear = "Unknown Year";
 		this.carMake = "Unknown Make";
 		this.carModel = "Unknown Model";
 	}

 	// Copy constructor

 	public ParkingPermit(ParkingPermit pStudent) {
 		this.permitNum = pStudent.getPermitNum();
 		this.carYear = pStudent.carYear;
 		this.carMake = pStudent.carMake;
 		this.carModel = pStudent.carModel;
 	}
 	
 	// Set ID for new student
 	
    public void setParkingPermit(int permitNum, String carYear, String carMake, String carModel) {
    	this.permitNum = getPermitNum();
		this.carMake = carMake;
		this.carModel = carModel;
		this.carYear = carYear;
	}

    // Get permit ID

	public final int getPermitNum() {
		return getRnd();
	}

	// Get car brand

	public String getCarMake() {
		return carMake;
	}

	// Get car model

	public String getCarModel() {
		return carModel;
	}

	// Get car year

	public String getCarYear() {
		return carYear;
	}

	// Get random number for permit ID

	public int getRnd() {
		Random rnd = new Random();
		int upperBound = 8999;
		int int_random = rnd.nextInt(upperBound) + 1000;
		return int_random;
	}

	// Set car brand
	
	public void setcarMake(String carMake) {
		this.carMake = carMake;
	}

	// Set car model

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	// Set car year

	public void setCarYear(String carYear) {
		this.carYear = carYear;
	}

	public String permitInfo() {
		String myReturn = "";
		myReturn += "Parking Permit: " + "\n" + this.permitNum + "\n";
		myReturn += this.getCarYear() + "\n" + this.getCarMake() + "\n" + this.getCarModel() + "/n";
		return myReturn;
	}

	//To String method
	 @Override
	 public String toString() {
		return "Parking Permit: " + getPermitNum() + "\n" + carYear + "\n" + carMake + "\n" + carModel + "\n";
	 }
}